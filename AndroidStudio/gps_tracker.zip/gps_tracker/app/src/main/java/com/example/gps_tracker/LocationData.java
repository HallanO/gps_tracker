package com.example.gps_tracker;

import java.io.Serializable;

public class LocationData implements Serializable {
    private String deviceId;
    private double latitude;
    private double longitude;
    private long timestamp;
    private int satellites;
    private double altitude;
    private double speed;
    private int battery;
    private double hdop;
    private long age;

    public LocationData() {
        // Default constructor required for Firebase
    }

    public LocationData(String deviceId, double latitude, double longitude, long timestamp,
                       int satellites, double altitude, double speed, int battery, double hdop, long age) {
        this.deviceId = deviceId;
        this.latitude = latitude;
        this.longitude = longitude;
        this.timestamp = timestamp;
        this.satellites = satellites;
        this.altitude = altitude;
        this.speed = speed;
        this.battery = battery;
        this.hdop = hdop;
        this.age = age;
    }

    // Getters and setters
    public String getDeviceId() { return deviceId; }
    public void setDeviceId(String deviceId) { this.deviceId = deviceId; }

    public double getLatitude() { return latitude; }
    public void setLatitude(double latitude) { this.latitude = latitude; }

    public double getLongitude() { return longitude; }
    public void setLongitude(double longitude) { this.longitude = longitude; }

    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }

    public int getSatellites() { return satellites; }
    public void setSatellites(int satellites) { this.satellites = satellites; }

    public double getAltitude() { return altitude; }
    public void setAltitude(double altitude) { this.altitude = altitude; }

    public double getSpeed() { return speed; }
    public void setSpeed(double speed) { this.speed = speed; }

    public int getBattery() { return battery; }
    public void setBattery(int battery) { this.battery = battery; }

    public double getHdop() { return hdop; }
    public void setHdop(double hdop) { this.hdop = hdop; }

    public long getAge() { return age; }
    public void setAge(long age) { this.age = age; }
}