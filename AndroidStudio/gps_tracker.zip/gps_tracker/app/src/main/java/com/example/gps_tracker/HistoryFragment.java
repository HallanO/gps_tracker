package com.example.gps_tracker;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import java.util.ArrayList;
import java.util.List;

public class HistoryFragment extends Fragment {
    private RecyclerView recyclerView;
    private SwipeRefreshLayout swipeRefresh;
    private LocationHistoryAdapter adapter;
    private FirebaseService firebaseService;
    
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_history, container, false);
        
        recyclerView = view.findViewById(R.id.recycler_view);
        swipeRefresh = view.findViewById(R.id.swipe_refresh);
        
        firebaseService = new FirebaseService();
        
        setupRecyclerView();
        loadHistory();
        
        swipeRefresh.setOnRefreshListener(this::loadHistory);
        
        return view;
    }
    
    private void setupRecyclerView() {
        // Enable point numbering and set click listener for history display
        adapter = new LocationHistoryAdapter(new ArrayList<>(), true, location -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).navigateToMapWithLocation(location);
            }
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);
    }
    
    private void loadHistory() {
        swipeRefresh.setRefreshing(true);
        firebaseService.getLocationHistory(new FirebaseService.LocationListCallback() {
            @Override
            public void onLocationsReceived(List<LocationData> locations) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        adapter.updateLocations(locations);
                        swipeRefresh.setRefreshing(false);
                    });
                }
            }
            
            @Override
            public void onError(String error) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        swipeRefresh.setRefreshing(false);
                    });
                }
            }
        });
    }
}