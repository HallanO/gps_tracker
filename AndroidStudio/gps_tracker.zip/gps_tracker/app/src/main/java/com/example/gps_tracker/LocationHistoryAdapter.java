package com.example.gps_tracker;

import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class LocationHistoryAdapter extends RecyclerView.Adapter<LocationHistoryAdapter.ViewHolder> {
    private List<LocationData> locations;
    private boolean showPointNumbers;
    private OnLocationClickListener clickListener;
    private int totalHistorySize = 0; // Add this field
    
    public LocationHistoryAdapter(List<LocationData> locations) {
        this.locations = locations;
        this.showPointNumbers = false;
    }
    
    public LocationHistoryAdapter(List<LocationData> locations, boolean showPointNumbers) {
        this.locations = locations;
        this.showPointNumbers = showPointNumbers;
    }
    
    public LocationHistoryAdapter(List<LocationData> locations, boolean showPointNumbers, OnLocationClickListener clickListener) {
        this.locations = locations;
        this.showPointNumbers = showPointNumbers;
        this.clickListener = clickListener;
    }
    
    // Add this method to set the total history size
    public void setTotalHistorySize(int totalSize) {
        this.totalHistorySize = totalSize;
    }
    
    public void setOnLocationClickListener(OnLocationClickListener listener) {
        this.clickListener = listener;
    }
    
    public void updateLocations(List<LocationData> newLocations) {
        this.locations = newLocations;
        notifyDataSetChanged();
    }
    
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.item_location_history, parent, false);
        return new ViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        LocationData location = locations.get(position);
        
        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, HH:mm:ss", Locale.getDefault());
        String timeStr = sdf.format(new Date(location.getTimestamp() * 1000));
        
        // Configure point number circle
        if (showPointNumbers) {
            int pointNumber;
            if (totalHistorySize > 0) {
                // For recent locations subset, calculate correct point number
                // Skip current location (index 0) and number the next 5 as totalSize-1, totalSize-2, etc.
                pointNumber = totalHistorySize - position - 1;
            } else {
                // For full history, use reverse numbering so oldest is #1
                pointNumber = locations.size() - position;
            }
            
            holder.tvPointNumber.setText(String.valueOf(pointNumber));
            holder.tvPointNumber.setVisibility(View.VISIBLE);
            
            // Highlight the most recent point (position 0) with different color
            if (position == 0) {
                // Current/most recent point - red circle
                GradientDrawable drawable = (GradientDrawable) ContextCompat.getDrawable(
                    holder.itemView.getContext(), R.drawable.circle_point_background).mutate();
                drawable.setColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.current_point_color));
                holder.tvPointNumber.setBackground(drawable);
            } else {
                // Regular points - blue circle
                GradientDrawable drawable = (GradientDrawable) ContextCompat.getDrawable(
                    holder.itemView.getContext(), R.drawable.circle_point_background).mutate();
                drawable.setColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.point_circle_color));
                holder.tvPointNumber.setBackground(drawable);
            }
        } else {
            holder.tvPointNumber.setVisibility(View.GONE);
        }
        
        holder.tvTime.setText(timeStr);
        // Set red color for the date/time text
        holder.tvTime.setTextColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.date_text_color));
        
        holder.tvCoordinates.setText(String.format(Locale.getDefault(), 
            "%.6f, %.6f", location.getLatitude(), location.getLongitude()));
        holder.tvSpeed.setText(String.format(Locale.getDefault(), "%.1f km/h", location.getSpeed()));
        holder.tvBattery.setText(String.format(Locale.getDefault(), "%d%%", location.getBattery()));
        holder.tvSatellites.setText(String.format(Locale.getDefault(), "%d satellites", location.getSatellites()));
        holder.tvAltitude.setText(String.format(Locale.getDefault(), "%.1f m", location.getAltitude()));
        
        // Set click listener
        holder.itemView.setOnClickListener(v -> {
            if (clickListener != null) {
                clickListener.onLocationClick(location);
            }
        });
    }
    
    @Override
    public int getItemCount() {
        return locations.size();
    }
    
    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvPointNumber, tvTime, tvCoordinates, tvSpeed, tvBattery, tvSatellites, tvAltitude;
        
        ViewHolder(View itemView) {
            super(itemView);
            tvPointNumber = itemView.findViewById(R.id.tv_point_number);
            tvTime = itemView.findViewById(R.id.tv_time);
            tvCoordinates = itemView.findViewById(R.id.tv_coordinates);
            tvSpeed = itemView.findViewById(R.id.tv_speed);
            tvBattery = itemView.findViewById(R.id.tv_battery);
            tvSatellites = itemView.findViewById(R.id.tv_satellites);
            tvAltitude = itemView.findViewById(R.id.tv_altitude);
        }
    }
}