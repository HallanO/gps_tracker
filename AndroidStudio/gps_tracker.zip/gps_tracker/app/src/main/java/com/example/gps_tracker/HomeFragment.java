package com.example.gps_tracker;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HomeFragment extends Fragment {
    private TextView tvLatitude, tvLongitude, tvSpeed, tvBattery, tvLastUpdate, tvSatellites, tvAltitude;
    private SwipeRefreshLayout swipeRefresh;
    private RecyclerView rvRecentLocations;
    private LocationHistoryAdapter recentLocationsAdapter;
    private FirebaseService firebaseService;
    private Handler handler;
    private Runnable refreshRunnable;
    private int totalHistoryPoints = 0;
    private LocationData currentLocationData; // Add this field to store current location
    
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        
        initViews(view);
        setupRecyclerView();
        firebaseService = new FirebaseService();
        handler = new Handler(Looper.getMainLooper());
        
        setupRefreshTimer();
        loadCurrentLocation();
        loadRecentLocations();
        
        swipeRefresh.setOnRefreshListener(() -> {
            loadCurrentLocation();
            loadRecentLocations();
        });
        
        return view;
    }
    
    private void initViews(View view) {
        tvLatitude = view.findViewById(R.id.tv_latitude);
        tvLongitude = view.findViewById(R.id.tv_longitude);
        tvSpeed = view.findViewById(R.id.tv_speed);
        tvBattery = view.findViewById(R.id.tv_battery);
        tvLastUpdate = view.findViewById(R.id.tv_last_update);
        tvSatellites = view.findViewById(R.id.tv_satellites);
        tvAltitude = view.findViewById(R.id.tv_altitude);
        swipeRefresh = view.findViewById(R.id.swipe_refresh);
        rvRecentLocations = view.findViewById(R.id.rv_recent_locations);
        
        // Add click listener to current location card
        View currentLocationCard = view.findViewById(R.id.current_location_card);
        currentLocationCard.setOnClickListener(v -> {
            if (currentLocationData != null && getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).navigateToMapWithLocation(currentLocationData);
            }
        });
    }
    
    private void setupRecyclerView() {
        // Enable point numbering and set click listener for recent locations display
        recentLocationsAdapter = new LocationHistoryAdapter(new ArrayList<>(), true, location -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).navigateToMapWithLocation(location);
            }
        });
        rvRecentLocations.setLayoutManager(new LinearLayoutManager(getContext()));
        rvRecentLocations.setAdapter(recentLocationsAdapter);
    }
    
    private void setupRefreshTimer() {
        refreshRunnable = new Runnable() {
            @Override
            public void run() {
                loadCurrentLocation();
                loadRecentLocations();
                handler.postDelayed(this, 1000); // Refresh every 1 second
            }
        };
        handler.post(refreshRunnable);
    }
    
    private void loadCurrentLocation() {
        firebaseService.getCurrentLocation(new FirebaseService.LocationCallback() {
            @Override
            public void onLocationReceived(LocationData location) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        updateUI(location);
                        swipeRefresh.setRefreshing(false);
                    });
                }
            }
            
            @Override
            public void onError(String error) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        swipeRefresh.setRefreshing(false);
                        // Handle error - could show a toast or update UI
                    });
                }
            }
        });
    }
    
    private void loadRecentLocations() {
        firebaseService.getLocationHistory(new FirebaseService.LocationListCallback() {
            @Override
            public void onLocationsReceived(List<LocationData> locations) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        // Update total points count
                        totalHistoryPoints = locations.size();
                        
                        // Get the last 5 recent locations (excluding current location if it's the first one)
                        List<LocationData> recentFive = new ArrayList<>();
                        if (locations.size() > 1) {
                            // Skip the first location (current) and get the next 5
                            int startIndex = 1; // Skip current location
                            int endIndex = Math.min(startIndex + 5, locations.size());
                            recentFive = locations.subList(startIndex, endIndex);
                        }
                        
                        // Set the total history size for proper numbering
                        recentLocationsAdapter.setTotalHistorySize(totalHistoryPoints);
                        recentLocationsAdapter.updateLocations(recentFive);
                        
                        // Update the last update text with current total
                        updateLastUpdateText();
                    });
                }
            }
            
            @Override
            public void onError(String error) {
                // Handle error
            }
        });
    }
    
    private void updateUI(LocationData location) {
        // Store current location data for click navigation
        this.currentLocationData = location;
        
        tvLatitude.setText(String.format(Locale.getDefault(), "%.6f", location.getLatitude()));
        tvLongitude.setText(String.format(Locale.getDefault(), "%.6f", location.getLongitude()));
        tvSpeed.setText(String.format(Locale.getDefault(), "%.1f km/h", location.getSpeed()));
        tvBattery.setText(String.format(Locale.getDefault(), "%d%%", location.getBattery()));
        tvSatellites.setText(String.valueOf(location.getSatellites()));
        tvAltitude.setText(String.format(Locale.getDefault(), "%.1f m", location.getAltitude()));
        
        // Calculate minutes ago
        long currentTime = System.currentTimeMillis() / 1000;
        long minutesAgo = (currentTime - location.getTimestamp()) / 60;
        
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        String timeStr = sdf.format(new Date(location.getTimestamp() * 1000));
        
        tvLastUpdate.setText(String.format(Locale.getDefault(), "%s (%d min ago) | Points: %d", 
            timeStr, minutesAgo, totalHistoryPoints));
    }
    
    private void updateLastUpdateText() {
        if (tvLastUpdate != null) {
            String currentText = tvLastUpdate.getText().toString();
            if (currentText.contains("Points:")) {
                String[] parts = currentText.split("\\| Points:");
                if (parts.length > 0) {
                    tvLastUpdate.setText(String.format(Locale.getDefault(), "%s| Points: %d", 
                        parts[0], totalHistoryPoints));
                }
            }
        }
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (handler != null && refreshRunnable != null) {
            handler.removeCallbacks(refreshRunnable);
        }
    }
}