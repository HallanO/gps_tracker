package com.example.gps_tracker;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MapFragment extends Fragment implements OnMapReadyCallback {
    private GoogleMap mMap;
    private FirebaseService firebaseService;
    private FloatingActionButton fabRefresh;
    private LocationData targetLocation;
    private Spinner spinnerDateFilter;
    private String selectedDate = ""; // Changed from "All Dates" to empty string
    private List<String> availableDates = new ArrayList<>();
    
    private static final String ARG_LOCATION = "target_location";
    
    public static MapFragment newInstance(LocationData location) {
        MapFragment fragment = new MapFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_LOCATION, location);
        fragment.setArguments(args);
        return fragment;
    }
    
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_map, container, false);
        
        // Get target location from arguments
        if (getArguments() != null) {
            targetLocation = (LocationData) getArguments().getSerializable(ARG_LOCATION);
        }
        
        firebaseService = new FirebaseService();
        fabRefresh = view.findViewById(R.id.fab_refresh);
        spinnerDateFilter = view.findViewById(R.id.spinner_date_filter);
        
        // Initialize spinner with loading placeholder
        List<String> initialList = new ArrayList<>();
        initialList.add("Loading dates...");
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(),
                android.R.layout.simple_spinner_item, initialList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDateFilter.setAdapter(adapter);
        
        // Load available dates
        loadAvailableDates();
        
        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager()
            .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
        
        fabRefresh.setOnClickListener(v -> loadMapData());
        
        return view;
    }
    
    private void loadAvailableDates() {
        firebaseService.getAvailableDates(new FirebaseService.DateListCallback() {
            @Override
            public void onDatesReceived(List<String> dates) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        availableDates = dates;
                        ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(),
                                android.R.layout.simple_spinner_item, availableDates);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spinnerDateFilter.setAdapter(adapter);
                        
                        // Set the default selection to the first item (latest date)
                        if (!availableDates.isEmpty()) {
                            selectedDate = availableDates.get(0);
                            spinnerDateFilter.setSelection(0);
                        }
                        
                        // Set listener after populating to avoid initial trigger
                        spinnerDateFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                selectedDate = availableDates.get(position);
                                loadMapData();
                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> parent) {
                                // Do nothing
                            }
                        });
                        
                        // Load map data with the default selection
                        loadMapData();
                    });
                }
            }
            
            @Override
            public void onError(String error) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        Toast.makeText(getContext(), "Error loading dates: " + error, Toast.LENGTH_SHORT).show();
                    });
                }
            }
        });
    }
    
    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setCompassEnabled(true);
        
        // Set normal/default map type instead of satellite
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        
        if (targetLocation != null) {
            // If we have a target location, zoom to it first
            zoomToLocation(targetLocation);
        }
        
        loadMapData();
    }
    
    private void zoomToLocation(LocationData location) {
        if (mMap != null) {
            LatLng position = new LatLng(location.getLatitude(), location.getLongitude());
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(position, 18));
        }
    }
    
    private BitmapDescriptor createNumberedMarker(int number, boolean isLatest) {
        int size = isLatest ? 80 : 60;
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        
        Paint circlePaint = new Paint();
        circlePaint.setAntiAlias(true);
        circlePaint.setColor(isLatest ? Color.RED : Color.BLUE);
        
        Paint strokePaint = new Paint();
        strokePaint.setAntiAlias(true);
        strokePaint.setColor(Color.WHITE);
        strokePaint.setStyle(Paint.Style.STROKE);
        strokePaint.setStrokeWidth(3);
        
        Paint textPaint = new Paint();
        textPaint.setAntiAlias(true);
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(isLatest ? 24 : 18);
        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        textPaint.setTextAlign(Paint.Align.CENTER);
        
        float centerX = size / 2f;
        float centerY = size / 2f;
        float radius = (size - 6) / 2f;
        
        // Draw circle
        canvas.drawCircle(centerX, centerY, radius, circlePaint);
        canvas.drawCircle(centerX, centerY, radius, strokePaint);
        
        // Draw number
        String text = String.valueOf(number);
        float textY = centerY + (textPaint.getTextSize() / 3);
        canvas.drawText(text, centerX, textY, textPaint);
        
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }
    
    private void loadMapData() {
        if (mMap == null) return;
        
        // Use the date filter to get locations
        firebaseService.getLocationsByDate(selectedDate, new FirebaseService.LocationListCallback() {
            @Override
            public void onLocationsReceived(List<LocationData> locations) {
                if (getActivity() != null && mMap != null) {
                    getActivity().runOnUiThread(() -> {
                        mMap.clear();
                        
                        if (!locations.isEmpty()) {
                            PolylineOptions polylineOptions = new PolylineOptions()
                                .color(0xFF0000FF)
                                .width(3);
                            
                            LatLng lastPosition = null;
                            LatLng targetPosition = null;
                            
                            // Reverse the list to show oldest first (point 1)
                            for (int i = locations.size() - 1; i >= 0; i--) {
                                LocationData location = locations.get(i);
                                LatLng position = new LatLng(location.getLatitude(), location.getLongitude());
                                
                                polylineOptions.add(position);
                                
                                // Calculate point number (oldest = 1, newest = highest number)
                                int pointNumber = locations.size() - i;
                                boolean isLatest = (i == 0); // Most recent location
                                boolean isTarget = targetLocation != null && 
                                    location.getLatitude() == targetLocation.getLatitude() && 
                                    location.getLongitude() == targetLocation.getLongitude();
                                
                                // Create numbered marker with special highlighting for target
                                BitmapDescriptor markerIcon;
                                if (isTarget) {
                                    markerIcon = createHighlightedMarker(pointNumber);
                                    targetPosition = position;
                                } else {
                                    markerIcon = createNumberedMarker(pointNumber, isLatest);
                                }
                                
                                mMap.addMarker(new MarkerOptions()
                                    .position(position)
                                    .title(isLatest ? "Current Location (Point " + pointNumber + ")" : "Point " + pointNumber)
                                    .snippet(String.format("Speed: %.1f km/h, Battery: %d%%", 
                                        location.getSpeed(), location.getBattery()))
                                    .icon(markerIcon));
                                
                                if (isLatest) {
                                    lastPosition = position;
                                }
                            }
                            
                            mMap.addPolyline(polylineOptions);
                            
                            // Zoom to target location if specified, otherwise to latest
                            if (targetPosition != null) {
                                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(targetPosition, 18));
                            } else if (lastPosition != null) {
                                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(lastPosition, 15));
                            }
                        } else {
                            // Show message if no locations found for selected date
                            Toast.makeText(getContext(), "No locations found for " + selectedDate, Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
            
            @Override
            public void onError(String error) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        Toast.makeText(getContext(), "Error loading map data: " + error, Toast.LENGTH_SHORT).show();
                    });
                }
            }
        });
    }
    
    private BitmapDescriptor createHighlightedMarker(int number) {
        int size = 90;
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        
        Paint circlePaint = new Paint();
        circlePaint.setAntiAlias(true);
        circlePaint.setColor(Color.YELLOW);
        
        Paint strokePaint = new Paint();
        strokePaint.setAntiAlias(true);
        strokePaint.setColor(Color.BLACK);
        strokePaint.setStyle(Paint.Style.STROKE);
        strokePaint.setStrokeWidth(4);
        
        Paint textPaint = new Paint();
        textPaint.setAntiAlias(true);
        textPaint.setColor(Color.BLACK);
        textPaint.setTextSize(26);
        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        textPaint.setTextAlign(Paint.Align.CENTER);
        
        float centerX = size / 2f;
        float centerY = size / 2f;
        float radius = (size - 8) / 2f;
        
        // Draw circle
        canvas.drawCircle(centerX, centerY, radius, circlePaint);
        canvas.drawCircle(centerX, centerY, radius, strokePaint);
        
        // Draw number
        String text = String.valueOf(number);
        float textY = centerY + (textPaint.getTextSize() / 3);
        canvas.drawText(text, centerX, textY, textPaint);
        
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }
}