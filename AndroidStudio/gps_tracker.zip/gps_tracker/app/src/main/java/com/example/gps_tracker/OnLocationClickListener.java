package com.example.gps_tracker;

public interface OnLocationClickListener {
    void onLocationClick(LocationData location);
}