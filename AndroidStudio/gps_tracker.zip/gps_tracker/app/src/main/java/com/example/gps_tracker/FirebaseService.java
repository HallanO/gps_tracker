package com.example.gps_tracker;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class FirebaseService {
    private static final String DEVICE_ID = "tracker_001";
    private DatabaseReference databaseRef;
    
    public interface LocationCallback {
        void onLocationReceived(LocationData location);
        void onError(String error);
    }
    
    public interface LocationListCallback {
        void onLocationsReceived(List<LocationData> locations);
        void onError(String error);
    }
    
    public interface DateListCallback {
        void onDatesReceived(List<String> dates);
        void onError(String error);
    }
    
    public FirebaseService() {
        FirebaseDatabase database = FirebaseDatabase.getInstance("https://gps-tracker-a713b-default-rtdb.firebaseio.com/");
        databaseRef = database.getReference();
    }
    
    public void getCurrentLocation(LocationCallback callback) {
        DatabaseReference currentRef = databaseRef.child("trackers").child(DEVICE_ID).child("current");
        
        currentRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                LocationData location = dataSnapshot.getValue(LocationData.class);
                if (location != null) {
                    callback.onLocationReceived(location);
                } else {
                    callback.onError("No current location data found");
                }
            }
            
            @Override
            public void onCancelled(DatabaseError databaseError) {
                callback.onError(databaseError.getMessage());
            }
        });
    }
    
    public void getLocationHistory(LocationListCallback callback) {
        DatabaseReference historyRef = databaseRef.child("trackers").child(DEVICE_ID).child("history");
        Query query = historyRef.orderByKey().limitToLast(100); // Get last 100 locations
        
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                List<LocationData> locations = new ArrayList<>();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    LocationData location = snapshot.getValue(LocationData.class);
                    if (location != null) {
                        locations.add(location);
                    }
                }
                Collections.reverse(locations); // Show newest first
                callback.onLocationsReceived(locations);
            }
            
            @Override
            public void onCancelled(DatabaseError databaseError) {
                callback.onError(databaseError.getMessage());
            }
        });
    }
    
    public void getRecentLocationsForMap(LocationListCallback callback) {
        DatabaseReference historyRef = databaseRef.child("trackers").child(DEVICE_ID).child("history");
        Query query = historyRef.orderByKey().limitToLast(40); // Get last 40 locations for map
        
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                List<LocationData> locations = new ArrayList<>();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    LocationData location = snapshot.getValue(LocationData.class);
                    if (location != null) {
                        locations.add(location);
                    }
                }
                callback.onLocationsReceived(locations);
            }
            
            @Override
            public void onCancelled(DatabaseError databaseError) {
                callback.onError(databaseError.getMessage());
            }
        });
    }
    
    // New method to get all available dates from location history
    public void getAvailableDates(DateListCallback callback) {
        DatabaseReference historyRef = databaseRef.child("trackers").child(DEVICE_ID).child("history");
        Query query = historyRef.orderByKey();
        
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Set<String> dateSet = new HashSet<>();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    LocationData location = snapshot.getValue(LocationData.class);
                    if (location != null) {
                        String date = dateFormat.format(new Date(location.getTimestamp() * 1000));
                        dateSet.add(date);
                    }
                }
                
                List<String> dates = new ArrayList<>(dateSet);
                Collections.sort(dates, Collections.reverseOrder()); // Sort dates in descending order
                
                // Removed "All Dates" option
                
                callback.onDatesReceived(dates);
            }
            
            @Override
            public void onCancelled(DatabaseError databaseError) {
                callback.onError(databaseError.getMessage());
            }
        });
    }
    
    // New method to get locations filtered by date
    public void getLocationsByDate(String date, LocationListCallback callback) {
        // If "All Dates" is selected, just get recent locations
        if (date.equals("All Dates")) {
            getRecentLocationsForMap(callback);
            return;
        }
        
        DatabaseReference historyRef = databaseRef.child("trackers").child(DEVICE_ID).child("history");
        Query query = historyRef.orderByKey();
        
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                List<LocationData> locations = new ArrayList<>();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    LocationData location = snapshot.getValue(LocationData.class);
                    if (location != null) {
                        String locationDate = dateFormat.format(new Date(location.getTimestamp() * 1000));
                        if (locationDate.equals(date)) {
                            locations.add(location);
                        }
                    }
                }
                
                callback.onLocationsReceived(locations);
            }
            
            @Override
            public void onCancelled(DatabaseError databaseError) {
                callback.onError(databaseError.getMessage());
            }
        });
    }
}